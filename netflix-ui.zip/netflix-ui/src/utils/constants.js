export const API_KEY = "81a258ed349c9a292099ca883d3637bb";
export const TMDB_BASE_URL = "https://api.themoviedb.org/3";