
import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth"

const firebaseConfig = {
  apiKey: "AIzaSyCUQkOgm3sp_AweB5BKiKOKwcyxe4bRzYg",
  authDomain: "react-netflix-clone2-82904.firebaseapp.com",
  projectId: "react-netflix-clone2-82904",
  storageBucket: "react-netflix-clone2-82904.appspot.com",
  messagingSenderId: "80438814725",
  appId: "1:80438814725:web:4046a35aa6b50ccf85146c",
  measurementId: "G-M4N8HPKTWC"
};


const app = initializeApp(firebaseConfig);
export const firebaseAuth = getAuth(app)